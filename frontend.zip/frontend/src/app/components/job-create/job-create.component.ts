import { Component } from '@angular/core';

@Component({
  selector: 'app-job-create',
  standalone: true,
  imports: [],
  templateUrl: './job-create.component.html',
  styleUrl: './job-create.component.scss'
})
export class JobCreateComponent {

}
